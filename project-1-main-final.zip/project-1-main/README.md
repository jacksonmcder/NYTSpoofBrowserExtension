# project-1

The starting point for a browser extension project
